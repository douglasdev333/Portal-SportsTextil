import EventWizard from "./EventWizard";

export default function CreateEventPage() {
  return <EventWizard mode="create" />;
}

import MinhaContaPage from '../../pages/MinhaContaPage';

export default function MinhaContaPageExample() {
  return <MinhaContaPage />;
}
